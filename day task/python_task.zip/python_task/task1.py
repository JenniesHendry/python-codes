print(7 // 2, -7 // 2, 7 % 2, -7 % 2)
print(4 / 2, type(4 / 2))
x = 256; y = 256; print(x is y)