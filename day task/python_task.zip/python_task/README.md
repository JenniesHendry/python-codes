since each operation is seperated by commas,we obtain an output in row such that first floor division gives us an output rounding the float data type into an integer,secondly floor division of negative number rounds to next negative number ,we aldready know in the number line the value of negative number increases when it tends to zero. Next modulus operation gives us the remainder, in case of modulus of negative number we know that in the quotient part the negative sign appears whereas leaving the modulus of both negative as well positive number returning a same output.
The division operation gives a float output,as well it displays the data type float.
This is a identity operator it gives output as true or false.
This is a identity operator it gives output as true or false.
floats use binary representation and hence cannot represent 0.1 and 0.2
In this question as we know true statement has value equivalent to 1 and false has value equivalent to 0, so true added to true gives the output 2.
Here first comparison operator is used which results as true because it compares the values,whereas an identity operator is used to compare the objects which results as false.
Here as we know bool('')as well bool([]) are falsy values hence the output displays false.
Error occurs because int command sorts a float values integer number as well decimal part and gives the integer number as the output, error occurs due to the extra unwanted addition of string in a float value, for integers,float etc we never use string.
Here the error is int should be added before input ,once added we obtain the desired output.